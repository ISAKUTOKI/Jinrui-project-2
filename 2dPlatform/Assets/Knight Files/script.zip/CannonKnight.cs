using System.Collections;
using System.Collections.Generic;
using System.Net.Sockets;
using UnityEngine;

public class CannonKnight : MonoBehaviour
{
    public FireBall prefab;
    public float interval;
    float nextFireTime;
    // Start is called before the first frame update
    void Start()
    {
        nextFireTime = interval;
    }

    // Update is called once per frame
    void Update()
    {
        if (nextFireTime <= Time.time)
        {
            Fire();
            nextFireTime = Time.time + interval;
        }
    }

    void Fire()
    {
        Instantiate(prefab, transform.position, Quaternion.identity);
    }
}
